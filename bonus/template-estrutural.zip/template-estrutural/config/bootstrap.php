<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/database.php';
require_once dirname(__DIR__) . '/src/Auth.php';
require_once dirname(__DIR__) . '/src/Csrf.php';
require_once dirname(__DIR__) . '/src/UsuarioRepository.php';

$envFile = dirname(__DIR__) . '/.env';
loadEnv($envFile);

$appEnv = getenv('APP_ENV') ?: 'development';
$appDebug = filter_var(getenv('APP_DEBUG') ?: 'false', FILTER_VALIDATE_BOOL);

if ($appEnv === 'production') {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
} else {
    ini_set('display_errors', $appDebug ? '1' : '0');
    ini_set('log_errors', '1');
}

$logDir = dirname(__DIR__) . '/logs';
if (!is_dir($logDir)) {
    mkdir($logDir, 0775, true);
}
ini_set('error_log', $logDir . '/php-errors.log');

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}
