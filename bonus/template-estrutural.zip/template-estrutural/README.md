# Template Estrutural PHP + PDO

Projeto-base didático para iniciar sistemas PHP/MySQL com:

- conexão PDO segura;
- autenticação com `password_hash()` e `password_verify()`;
- sessões;
- proteção de páginas restritas;
- token CSRF;
- CRUD de usuários;
- Prepared Statements;
- escape de saída HTML;
- estrutura organizada por responsabilidade;
- banco SQL inicial;
- arquivo `.env.example`.

## Requisitos

- PHP 8.1 ou superior
- MySQL 8 / MariaDB compatível
- Apache/Nginx ou XAMPP
- Extensão `pdo_mysql`

## 1. Banco de dados

Importe:

`sql/schema.sql`

## 2. Configuração

Copie:

`.env.example`

para:

`.env`

e ajuste:

DB_HOST=localhost
DB_NAME=guia_sql
DB_USER=root
DB_PASS=

> Em produção, não publique o arquivo `.env`.

## 3. Primeiro administrador

Abra temporariamente:

`tools/criar_admin.php`

Acesse o arquivo uma única vez no navegador, crie o administrador e depois APAGUE o arquivo do servidor.

## 4. Document root

Aponte o servidor web preferencialmente para a pasta:

`public/`

No XAMPP, para estudo, você também pode colocar a pasta inteira em `htdocs` e acessar `public/`.

## Estrutura

template-estrutural/
├── .env.example
├── README.md
├── config/
│   ├── bootstrap.php
│   └── database.php
├── public/
│   ├── index.php
│   ├── login.php
│   ├── logout.php
│   ├── dashboard.php
│   ├── css/app.css
│   └── usuarios/
│       ├── lista.php
│       ├── novo.php
│       ├── salvar.php
│       ├── editar.php
│       ├── atualizar.php
│       └── excluir.php
├── src/
│   ├── Auth.php
│   ├── Csrf.php
│   └── UsuarioRepository.php
├── sql/schema.sql
├── tools/criar_admin.php
└── logs/.gitkeep

## Segurança aplicada

- Nunca concatenar entrada do usuário em SQL.
- Senhas armazenadas somente como hash.
- Regeneração do ID da sessão após login.
- Token CSRF em operações de escrita.
- Exclusão por POST.
- Escape com `htmlspecialchars()` na saída HTML.
- Erros técnicos enviados para log.
- Credenciais fora do código-fonte.

## Observação

Este é um template didático. Em projetos reais, acrescente controle de permissões, limitação de tentativas de login, HTTPS, política de cookies, backups, auditoria e monitoramento.
