<?php
declare(strict_types=1);

final class UsuarioRepository
{
    public function __construct(private PDO $pdo)
    {
    }

    public function listar(string $termo = ''): array
    {
        $sql = "SELECT id, nome, email, ativo, criado_em
                FROM usuarios
                WHERE nome LIKE :termo
                   OR email LIKE :termo
                ORDER BY id DESC
                LIMIT 100";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            ':termo' => '%' . $termo . '%',
        ]);

        return $stmt->fetchAll();
    }

    public function porId(int $id): ?array
    {
        $stmt = $this->pdo->prepare(
            "SELECT id, nome, email, ativo, criado_em
             FROM usuarios
             WHERE id = :id
             LIMIT 1"
        );

        $stmt->execute([':id' => $id]);

        $usuario = $stmt->fetch();

        return $usuario ?: null;
    }

    public function porEmail(string $email): ?array
    {
        $stmt = $this->pdo->prepare(
            "SELECT id, nome, email, senha, ativo
             FROM usuarios
             WHERE email = :email
             LIMIT 1"
        );

        $stmt->execute([':email' => $email]);

        $usuario = $stmt->fetch();

        return $usuario ?: null;
    }

    public function criar(string $nome, string $email, string $senha): int
    {
        $stmt = $this->pdo->prepare(
            "INSERT INTO usuarios (nome, email, senha)
             VALUES (:nome, :email, :senha)"
        );

        $stmt->execute([
            ':nome' => $nome,
            ':email' => $email,
            ':senha' => password_hash($senha, PASSWORD_DEFAULT),
        ]);

        return (int) $this->pdo->lastInsertId();
    }

    public function atualizar(int $id, string $nome, string $email, bool $ativo): void
    {
        $stmt = $this->pdo->prepare(
            "UPDATE usuarios
             SET nome = :nome,
                 email = :email,
                 ativo = :ativo
             WHERE id = :id"
        );

        $stmt->execute([
            ':nome' => $nome,
            ':email' => $email,
            ':ativo' => $ativo ? 1 : 0,
            ':id' => $id,
        ]);
    }

    public function excluir(int $id): void
    {
        $stmt = $this->pdo->prepare(
            "DELETE FROM usuarios
             WHERE id = :id"
        );

        $stmt->execute([':id' => $id]);
    }
}
