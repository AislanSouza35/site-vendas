<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

$mensagem = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if ($nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($senha) < 8) {
        $mensagem = 'Informe nome, e-mail válido e senha com pelo menos 8 caracteres.';
    } else {
        try {
            $repo = new UsuarioRepository(db());
            $id = $repo->criar($nome, $email, $senha);
            $mensagem = "Administrador criado com ID {$id}. APAGUE este arquivo do servidor.";
        } catch (Throwable $e) {
            error_log($e->getMessage());
            $mensagem = 'Não foi possível criar o administrador.';
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Criar administrador</title>
</head>
<body>
    <h1>Criar primeiro administrador</h1>

    <?php if ($mensagem): ?>
        <p><?= e($mensagem) ?></p>
    <?php endif; ?>

    <form method="post">
        <input name="nome" placeholder="Nome" required><br><br>
        <input type="email" name="email" placeholder="E-mail" required><br><br>
        <input type="password" name="senha" placeholder="Senha (mín. 8)" required><br><br>
        <button type="submit">Criar</button>
    </form>

    <p><strong>Após criar o administrador, apague este arquivo.</strong></p>
</body>
</html>
