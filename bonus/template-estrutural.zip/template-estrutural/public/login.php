<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

if (Auth::check()) {
    header('Location: /dashboard.php');
    exit;
}

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Csrf::requireValid();

    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $senha === '') {
        $erro = 'Informe e-mail e senha válidos.';
    } else {
        $repo = new UsuarioRepository(db());
        $usuario = $repo->porEmail($email);

        if (
            $usuario
            && (int) $usuario['ativo'] === 1
            && password_verify($senha, $usuario['senha'])
        ) {
            Auth::login((int) $usuario['id'], $usuario['nome']);
            header('Location: /dashboard.php');
            exit;
        }

        $erro = 'E-mail ou senha inválidos.';
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Login</title>
    <link rel="stylesheet" href="/css/app.css">
</head>
<body class="auth-page">
    <main class="card auth-card">
        <h1>Entrar</h1>

        <?php if ($erro): ?>
            <div class="alert"><?= e($erro) ?></div>
        <?php endif; ?>

        <form method="post">
            <?= Csrf::field() ?>

            <label>
                E-mail
                <input type="email" name="email" required autocomplete="email">
            </label>

            <label>
                Senha
                <input type="password" name="senha" required autocomplete="current-password">
            </label>

            <button type="submit">Entrar</button>
        </form>
    </main>
</body>
</html>
