<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Método não permitido.');
}

Csrf::requireValid();
Auth::logout();

header('Location: /login.php');
exit;
