<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

header('Location: ' . (Auth::check() ? '/dashboard.php' : '/login.php'));
exit;
