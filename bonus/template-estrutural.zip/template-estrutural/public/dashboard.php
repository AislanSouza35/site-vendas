<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

Auth::requireLogin();
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard</title>
    <link rel="stylesheet" href="/css/app.css">
</head>
<body>
<header class="topbar">
    <strong>Sistema PHP + PDO</strong>
    <nav>
        <a href="/dashboard.php">Dashboard</a>
        <a href="/usuarios/lista.php">Usuários</a>
        <form method="post" action="/logout.php" class="inline">
            <?= Csrf::field() ?>
            <button type="submit" class="link-button">Sair</button>
        </form>
    </nav>
</header>

<main class="container">
    <section class="hero card">
        <h1>Olá, <?= e(Auth::nome()) ?>!</h1>
        <p>Use este template como base para novos sistemas.</p>
        <a class="button" href="/usuarios/lista.php">Gerenciar usuários</a>
    </section>
</main>
</body>
</html>
