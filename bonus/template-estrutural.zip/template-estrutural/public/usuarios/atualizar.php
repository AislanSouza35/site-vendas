<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';
Auth::requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Método não permitido.');
}

Csrf::requireValid();

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$ativo = isset($_POST['ativo']);

if (!$id || $nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    exit('Dados inválidos.');
}

try {
    $repo = new UsuarioRepository(db());
    $repo->atualizar($id, $nome, $email, $ativo);

    header('Location: /usuarios/lista.php');
    exit;
} catch (Throwable $e) {
    error_log($e->getMessage());
    http_response_code(500);
    exit('Não foi possível atualizar o usuário.');
}
