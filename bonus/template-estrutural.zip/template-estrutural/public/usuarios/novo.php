<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';
Auth::requireLogin();
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Novo usuário</title>
    <link rel="stylesheet" href="/css/app.css">
</head>
<body>
<main class="container narrow">
    <div class="card">
        <h1>Novo usuário</h1>

        <form method="post" action="/usuarios/salvar.php">
            <?= Csrf::field() ?>

            <label>Nome
                <input name="nome" required maxlength="120">
            </label>

            <label>E-mail
                <input type="email" name="email" required maxlength="160">
            </label>

            <label>Senha
                <input type="password" name="senha" required minlength="8">
            </label>

            <button type="submit">Cadastrar</button>
            <a href="/usuarios/lista.php">Cancelar</a>
        </form>
    </div>
</main>
</body>
</html>
