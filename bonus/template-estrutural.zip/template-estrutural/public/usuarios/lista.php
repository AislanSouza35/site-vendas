<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

Auth::requireLogin();

$termo = trim($_GET['q'] ?? '');
$repo = new UsuarioRepository(db());
$usuarios = $repo->listar($termo);
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Usuários</title>
    <link rel="stylesheet" href="/css/app.css">
</head>
<body>
<header class="topbar">
    <strong>Usuários</strong>
    <nav><a href="/dashboard.php">Dashboard</a></nav>
</header>

<main class="container">
    <div class="actions">
        <form method="get" class="search">
            <input name="q" value="<?= e($termo) ?>" placeholder="Buscar nome ou e-mail">
            <button>Buscar</button>
        </form>
        <a class="button" href="/usuarios/novo.php">Novo usuário</a>
    </div>

    <div class="card table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($usuarios as $u): ?>
                <tr>
                    <td><?= (int) $u['id'] ?></td>
                    <td><?= e($u['nome']) ?></td>
                    <td><?= e($u['email']) ?></td>
                    <td><?= (int) $u['ativo'] === 1 ? 'Ativo' : 'Inativo' ?></td>
                    <td class="row-actions">
                        <a href="/usuarios/editar.php?id=<?= (int) $u['id'] ?>">Editar</a>

                        <form method="post" action="/usuarios/excluir.php" class="inline"
                              onsubmit="return confirm('Excluir este usuário?')">
                            <?= Csrf::field() ?>
                            <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
                            <button class="link-button danger" type="submit">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>
