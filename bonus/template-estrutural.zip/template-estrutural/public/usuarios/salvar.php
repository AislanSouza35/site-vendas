<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';
Auth::requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Método não permitido.');
}

Csrf::requireValid();

$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';

if ($nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($senha) < 8) {
    exit('Dados inválidos.');
}

try {
    $repo = new UsuarioRepository(db());
    $repo->criar($nome, $email, $senha);

    header('Location: /usuarios/lista.php');
    exit;
} catch (Throwable $e) {
    error_log($e->getMessage());
    http_response_code(500);
    exit('Não foi possível cadastrar o usuário.');
}
