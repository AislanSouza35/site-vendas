<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';
Auth::requireLogin();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    http_response_code(400);
    exit('ID inválido.');
}

$repo = new UsuarioRepository(db());
$usuario = $repo->porId($id);

if (!$usuario) {
    http_response_code(404);
    exit('Usuário não encontrado.');
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Editar usuário</title>
    <link rel="stylesheet" href="/css/app.css">
</head>
<body>
<main class="container narrow">
    <div class="card">
        <h1>Editar usuário</h1>

        <form method="post" action="/usuarios/atualizar.php">
            <?= Csrf::field() ?>
            <input type="hidden" name="id" value="<?= (int) $usuario['id'] ?>">

            <label>Nome
                <input name="nome" value="<?= e($usuario['nome']) ?>" required maxlength="120">
            </label>

            <label>E-mail
                <input type="email" name="email" value="<?= e($usuario['email']) ?>" required maxlength="160">
            </label>

            <label class="checkbox">
                <input type="checkbox" name="ativo" value="1" <?= (int) $usuario['ativo'] === 1 ? 'checked' : '' ?>>
                Usuário ativo
            </label>

            <button type="submit">Salvar alterações</button>
            <a href="/usuarios/lista.php">Cancelar</a>
        </form>
    </div>
</main>
</body>
</html>
