<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';
Auth::requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Método não permitido.');
}

Csrf::requireValid();

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    http_response_code(400);
    exit('ID inválido.');
}

if ($id === Auth::id()) {
    http_response_code(400);
    exit('Você não pode excluir o usuário da própria sessão.');
}

try {
    $repo = new UsuarioRepository(db());
    $repo->excluir($id);

    header('Location: /usuarios/lista.php');
    exit;
} catch (Throwable $e) {
    error_log($e->getMessage());
    http_response_code(500);
    exit('Não foi possível excluir o usuário.');
}
